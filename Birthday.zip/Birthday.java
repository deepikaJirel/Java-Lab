import java.util.Scanner;

public class Birthday {
    public static void main(String[] args) {
        Scanner inputScnr = new Scanner(System.in);
        System.out.println(
            "When were you born? (DD/MM/YYYY)");
        System.out.println("Enter your birth day");
        String Userday = inputScnr.nextLine();
        System.out.println("Enter your birth month");
        String Usermonths = inputScnr.nextLine();
        System.out.println("Enter your birth year");
        int Useryear = inputScnr.nextInt();
        System.out.println("Day: " + Userday);
        System.out.println("Month: " + Usermonths);
        System.out.println("Year: " + Useryear);
    }
}
