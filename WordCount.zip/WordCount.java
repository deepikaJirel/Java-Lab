import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class WordCount {
    /**
     * Creates a file, writes provided string to file, returns File object
     *
     * @param filename the name of the file that will be created.
     * @param s        String, text that will write in the file.
     * @return return the file that is created.
     * @throws IOException if an I/O error occurs
     */
    public static File writeText(String filename, String s) throws IOException {
        File file = new File(filename);
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write(s);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return file;
    }

    /**
     * Counts number of words in file
     * A word is any text separated by a whitespace
     *
     * @param f count words in.
     * @return the number of words in the file
     * @throws IOException if an I/O error occurs
     */
    public static int countWords(File f) throws IOException {
        int CountWord = 0;
        try (BufferedReader reader = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] words = line.split("\\s+");
                CountWord += words.length;
            }
        }
        return CountWord;
    }

    public static void main(String[] args) {
        try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in))) {
            System.out.print("What is the name of the file? ");
            String filename = bufferedReader.readLine();

            System.out.print("What would you like to print to the file? ");
            String message = bufferedReader.readLine();

            File file = writeText(filename, message);
            int countWord = countWords(file);

            System.out.println(filename + " contains " + countWord + " words");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
