import java.util.ArrayList;
import java.util.Random;

/*
 *Represents an actor in the game
 */
public class Actor {
//private classs
    private String name;//Name of the hero
    private int health; //health points of the player
    private final int maxDamage = 5; //maximun damage that a hero can make
    private int row;// current position of the actor's row
    private int col;// current position of the actor's column
/*
 * Default constructor
 */
    public Actor() {
    }

    /**
     * Constructor to initialize the actor with a name and health
     *
     * @param name Name of the actor
     * @param health Health point so the actor
     */
    public Actor(String name, int health) {
        this.name = name;
        this.health = health;
        this.row = 0;
        this.col = 0;
    }

    /**
     * checks if the actor is alive or not
     * @return isAlive if health is greater than 0.
     */
    public boolean isAlive() {
        return health > 0;
    }

    /**
     * @param dungeonSize Size of the dungeon
     * @return true if hero is at exit position, else false
     */
    public boolean hasEscaped(int dungeonSize) {
        return row == dungeonSize - 1 && col == dungeonSize - 1;
    }

    /**
     * Checks if the actor is in the same room as another actor
     * @param other
     * @return true if both are on the same room , else false
     */
    public boolean inSameRoom(Actor other) {
        return row == other.row && col == other.col;
    }

    /**
     * Checks if the actor is in the adjacent room
     * @param other Other actor
     * @return true if both actors are in adjacent rooms,otherwise false
     */
    public boolean inAdjacentRoom(Actor other) {
        return Math.abs(row - other.row) <= 1 && Math.abs(col - other.col) <= 1;
    }

    /**
     * Inflicts damage on another actor
     * @param other Other actor
     */
    public void hit(Actor other) {
        Random rand = new Random();
        int damage = rand.nextInt(maxDamage) + 1;
        other.health -= damage;
    }

    /**
     * Moves the actor  in the specified direction within the dungeon.
     * @param direction   of the hero moves east,west,north,south
     * @param dungeonSize size of the dungeon
     * @return
     */
    public boolean move(String direction, int dungeonSize) {
        switch (direction) {
            case "north":
                if (row > 0) {
                    row--;
                    return true;
                }
                break;
            case "south":
                if (row < dungeonSize - 1) {
                    row++;
                    return true;
                }
                break;
            case "west":
                if (col > 0) {
                    col--;
                    return true;
                }
                break;
            case "east":
                if (col < dungeonSize - 1) {
                    col++;
                    return true;
                }
                break;
        }
        return false;
    }
    /*
     * Reduces the health of the actor by a specified amount.
     * @param  amount the amount to reduce health by
     */
    public void reduceHealth(int amount) {
        this.health -= amount;
    }
    @Override
    public String toString() {
        return name + " at " + row + ", " + col + " with " + health + " health";
    }



    /**
     * Creates a list of monsters for dungeon.
     * @param dungeonSize Size of the dungeon
     * @return the list of the monsters:
     */
    public static ArrayList<Actor> makeMonsters(int dungeonSize) {
        ArrayList<Actor> monsters = new ArrayList<>();
        Random rand = new Random();
        int numRooms = dungeonSize * dungeonSize;
        int numMonsters = numRooms / 6;
        for (int i = 0; i < numMonsters; i++) {
            int monsterRow, monsterCol;
            do {
                monsterRow = rand.nextInt(dungeonSize);
                monsterCol = rand.nextInt(dungeonSize);
            } while (monsterRow == 0 && monsterCol == 0); // Neglects hero's start position

            Actor monster = new Actor("Monster " + (i + 1), 25);
            monster.row = monsterRow;
            monster.col = monsterCol;
            monsters.add(monster);
        }
        return monsters;
    }

    /**
     * @param player Player character
     * @param monsters the list of monster character
     */
    public static void fight(Actor player, ArrayList<Actor> monsters) {
        for (Actor monster : monsters) {
            if (player.inSameRoom(monster)) {
                while (player.isAlive() && monster.isAlive()) {
                    player.hit(monster);
                    if (monster.isAlive()) {
                        monster.hit(player);
                    }
                }
                System.out.println(player);
                if (!player.isAlive()) {
                    System.out.println("You have been defeated by " + monster.name);
                    return;
                } else {
                    System.out.println(monster.name + " has been defeated!");
                    monsters.remove(player);
                    
                    
                }
            }
        }
    }

    /**
     * Counts the number of monsters near the player.
     * @param player Player character
     * @param monsters the list of monster characters
     * @return count the nearby monsters:
     */
    public static int countNearByMonsters(Actor player, ArrayList<Actor> monsters) {
        int count = 0;
        for (Actor monster : monsters) {
            if (player.inAdjacentRoom(monster)) {
                count++;
            }
        }
        return count;
}

}

