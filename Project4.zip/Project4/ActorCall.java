import java.util.ArrayList;
import java.util.Scanner;

public class ActorCall {

    /**
     * Main method used to run the game
     * @param args command line arguments
     */
    public static void main(String[] args) {
        //Main class
        Actor actor = new Actor();//Creating a object from class ActorCall

        Scanner scanner = new Scanner(System.in);

        System.out.print("What is your name, heroic adventurer? ");
        String playerName = scanner.nextLine();//Let the user input name of the hero.

        int dungeonSize;
        do {
            System.out.print("How wide of a catacomb do you want to face (5-10)? ");
            dungeonSize = scanner.nextInt();//inputs the size of catacomb N from the user.
            if (dungeonSize < 5 || dungeonSize > 10) {
                System.out.println("That is not a valid catacomb size!");  //prints when N is not between 5 and 10.
            }
        } while (dungeonSize < 5 || dungeonSize > 10);

        Actor player = new Actor(playerName, 100);
        ArrayList<Actor> monsters = actor.makeMonsters(dungeonSize);

        System.out.println(player);

        while (player.isAlive() && !player.hasEscaped(dungeonSize)) {
            int nearbyMonsters = actor.countNearByMonsters(player, monsters);
            System.out.println("You smell " + nearbyMonsters + " monsters nearby.");

            System.out.print("Which way do you want to go (north, south, east, west)? ");
            String direction = scanner.next();

            if (player.move(direction, dungeonSize)) {
                player.reduceHealth(2); // Reduce health for movement
                System.out.println(player);

                if (nearbyMonsters > 0) {
                    actor.fight(player, monsters);
                }
            } else {
                System.out.println("You can't move that way!");
            }
        }

        if (player.hasEscaped(dungeonSize)) {
            System.out.println("You have escaped the catacomb");
        } else {
            System.out.println("You have been defeated by the monsters!");
        }
        scanner.close();
    }

}