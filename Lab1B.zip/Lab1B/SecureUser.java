/**
 * @SecureUser} class extends the
 * @User class, adding features for secure authentication with account after multiple failed attempts.
 *
 * It tracks the number of consecutive failed login attempts and locks the account
 * after reaching a maximum limit. The account can be manually unlocked using the
 * @UnLocked  method.
 */
public class SecureUser extends User {

    private int failedAttempts; //  stores the  consecutive failed authentications
    private final int maxAttempts = 3; // maximum number of failed attempt
    private boolean isLocked; //checks if the account is locked

    /**
     * Constructs a  SecureUser with the specific username and password.
     * 
     * @param username the username for the user account.
     * @param password the password for the user account.
     */

    public SecureUser(String username, String password) {
        super(username, password);
        this.failedAttempts = 0;
        this.isLocked = false;
    }

    @Override
    public boolean authenticate(String inputPassword) {
        if (isLocked) {
            System.out.println("This  account is locked due to multiple attempts.");
            return false;
        }

        if (super.authenticate(inputPassword)) {
            failedAttempts = 0; // Reset failed attempts on success
            return true;
        } else {
            failedAttempts++;
            System.out.println("Authentication failed. Failed attempts: " + failedAttempts);
            if (failedAttempts >= maxAttempts) {
                isLocked = true;
                System.out.println("This account is locked now.");
            }
            return false;
        }
    }
/**
     * Unlocks the account by resetting  failed attempts counter and unlocking the account.
    
     */
    public void unLocked() {
        this.failedAttempts = 0;
        this.isLocked = false;
        System.out.println("This account is reset now.");
    }
}