rootProject.name = "javaassignment"

