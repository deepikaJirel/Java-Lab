import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Scanner;

public class DeliverySimulation {
    private static final int TOTAL_PACKAGES = 100;
    private static double PERCENT_BY_DRONE = 0.5; //  given percentage in question: can be changed as needed:

    /**
     *
     * @param args
     */
    public static void main(String[] args) {
        List<TrainEvent> trainSchedule = readTrainSchedule("C:\\Users\\Dell\\Downloads\\javaassignment\\src\\main\\java\\train_schedule.txt");
        int numDrones = (int) (TOTAL_PACKAGES * PERCENT_BY_DRONE);
        int numTrucks = (int) Math.ceil((TOTAL_PACKAGES - numDrones) / 10.0);

        PriorityQueue<Event> eventQueue = new PriorityQueue<>();
        TrainTruck trainTrack = new TrainTruck();
        List<Truck> trucks = new ArrayList<>();

        // Schedule train events
        for (TrainEvent te : trainSchedule) {
            eventQueue.add(new Event(te.startTime, EventType.TRAIN_START, null, "Train blocking crossing"));
            eventQueue.add(new Event(te.endTime, EventType.TRAIN_END, null, "Train no longer blocking crossing"));
        }

        // Schedule truck start events
        for (int i = 0; i < numTrucks; i++) {
            double departTime = i * Constants.TRUCK_DEPARTURE_OFFSET;
            Truck truck = new Truck(i + 1, departTime);
            trucks.add(truck);
            eventQueue.add(new Event(departTime, EventType.TRUCK_START, truck, "Truck " + truck.id + " begins journey"));
        }

        // Process events
        double simulationTime = 0.0;
        List<Double> truckTripTimes = new ArrayList<>();

        while (!eventQueue.isEmpty()) {
            Event event = eventQueue.poll();
            simulationTime = event.time;

            System.out.printf("%.1f: %s%n", event.time, event.description);

            switch (event.type) {
                case TRUCK_START:
                    double timeToCrossing = (Constants.TRUCK_DISTANCE_TO_CROSSING / Constants.TRUCK_SPEED) * 60;
                    Event atCrossingEvent = new Event(
                            simulationTime + timeToCrossing,
                            EventType.TRUCK_AT_CROSSING,
                            event.truck,
                            "Truck " + event.truck.id + " arrives at crossing"
                    );
                    eventQueue.add(atCrossingEvent);
                    break;

                case TRUCK_AT_CROSSING:
                    if (trainTrack.isBlocked || trainTrack.hasWaitingTrucks()) {
                        trainTrack.addWaitingTruck(event.truck);
                        System.out.printf("%.1f: TRUCK %d waits at crossing%n", simulationTime, event.truck.id);
                    } else {
                        Event crossEvent = new Event(
                                simulationTime + 1.0,
                                EventType.TRUCK_CROSS,
                                event.truck,
                                "Truck " + event.truck.id + " crosses crossing"
                        );
                        eventQueue.add(crossEvent);
                    }
                    break;

                case TRUCK_CROSS:
                    double timeAfterCrossing = (Constants.TRUCK_DISTANCE_AFTER_CROSSING / Constants.TRUCK_SPEED) * 60;
                    Event endEvent = new Event(
                            simulationTime + timeAfterCrossing,
                            EventType.TRUCK_END,
                            event.truck,
                            "Truck " + event.truck.id + " completes delivery"
                    );
                    eventQueue.add(endEvent);
                    event.truck.tripTime = endEvent.time - event.truck.startTime;
                    break;

                case TRUCK_END:
                    truckTripTimes.add(event.truck.tripTime);
                    break;

                case TRAIN_START:
                    trainTrack.blockTrack();
                    break;

                case TRAIN_END:
                    trainTrack.unblockTrack();
                    double currentTime = simulationTime;
                    while (trainTrack.hasWaitingTrucks()) {
                        Truck nextTruck = trainTrack.getNextWaitingTruck();
                        Event crossEvent = new Event(
                                currentTime + 1.0,
                                EventType.TRUCK_CROSS,
                                nextTruck,
                                "Truck " + nextTruck.id + " crosses crossing"
                        );
                        eventQueue.add(crossEvent);
                        currentTime += 1.0;
                    }
                    break;
            }
        }

        // Drone calculations
        double droneTripTime = Math.sqrt(2 * Constants.DRONE_DISTANCE / Constants.DRONE_ACCELERATION) / 60; // minutes
        double totalDroneTime = droneTripTime;

        // Truck statistics
        double totalTruckTime = truckTripTimes.stream().max(Double::compare).orElse(0.0);
        double avgTruckTime = truckTripTimes.stream().mapToDouble(Double::doubleValue).average().orElse(0.0);

        // Total delivery time
        double totalDeliveryTime = Math.max(totalDroneTime, totalTruckTime);

        // Print statistics
        System.out.println("\n=== Statistics ===");
        System.out.println("Drones: " + numDrones);
        System.out.println("Trucks: " + numTrucks);
        System.out.println("Train Schedule:");
        for (TrainEvent te : trainSchedule) {
            System.out.printf("Blocked from %.1f to %.1f minutes%n", te.startTime, te.endTime);
        }
        System.out.println("Truck Trip Times:");
        for (int i = 0; i < trucks.size(); i++) {
            System.out.printf("Truck %d: %.1f minutes%n", i + 1, truckTripTimes.get(i));
        }
        System.out.printf("Average Truck Trip Time: %.1f minutes%n", avgTruckTime);
        System.out.printf("Total Truck Delivery Time: %.1f minutes%n", totalTruckTime);
        System.out.printf("Drone Trip Time: %.1f minutes%n", droneTripTime);
        System.out.printf("Total Drone Delivery Time: %.1f minutes%n", totalDroneTime);
        System.out.printf("Total Delivery Time: %.1f minutes%n", totalDeliveryTime);
    }

    /**
     *
     * @param filename
     * @return
     */
    private static List<TrainEvent> readTrainSchedule(String filename) {
        List<TrainEvent> schedule = new ArrayList<>();
        try (Scanner sc = new Scanner(new File(filename))) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine().trim();
                if (!line.isEmpty()) {
                    String[] parts = line.split(" ");
                    double start = Double.parseDouble(parts[0]);
                    double duration = Double.parseDouble(parts[1]);
                    schedule.add(new TrainEvent(start, duration));
                }
            }
        } catch (FileNotFoundException e) {
            System.err.println("Error reading train schedule: " + e.getMessage());
        }
        return schedule;
    }
}
