public class TrainEvent {
    double startTime;
    double endTime;

    /**
     *
     * @param startTime
     * @param duration
     */
    public TrainEvent(double startTime, double duration) {
        this.startTime = startTime;
        this.endTime = startTime + duration;

    }
}
